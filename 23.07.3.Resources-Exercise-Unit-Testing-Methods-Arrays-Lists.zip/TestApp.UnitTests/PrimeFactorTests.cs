﻿using NUnit.Framework;

namespace TestApp.UnitTests;

public class PrimeFactorTests
{
    [Test]
    public void Test_FindLargestPrimeFactor_NumberLowerThanTwo()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_FindLargestPrimeFactor_PrimeNumber()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_FindLargestPrimeFactor_LargeNumber()
    {
        // TODO: finish the test
    }
}
