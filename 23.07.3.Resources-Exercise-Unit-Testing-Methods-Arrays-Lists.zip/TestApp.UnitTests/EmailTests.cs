﻿using NUnit.Framework;

namespace TestApp.UnitTests;

public class EmailTests
{
    // TODO: finish test
    [Test]
    public void Test_IsValidEmail_ValidEmail()
    {
        // Arrange
        string validEmail = "test@example.com";

        // Act

        // Assert
    }

    [Test]
    public void Test_IsValidEmail_InvalidEmail()
    {
        // TODO: finish test
    }

    [Test]
    public void Test_IsValidEmail_NullInput()
    {
        // TODO: finish test
    }
}
